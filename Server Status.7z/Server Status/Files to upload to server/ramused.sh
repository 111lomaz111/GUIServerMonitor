#! /bin/bash

free -m 1 1 | awk 'FNR == 2 {print $3}'

