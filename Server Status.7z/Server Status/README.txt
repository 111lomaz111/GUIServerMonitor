# GUIServerMonitor

It`s created to show in GUI all parameters of our server(i`ts cpu load, ram etc)



If you want to test it, necessarily is to upload 3 files what are in folder 
<Files to upload to server> 

directly to home directory of your user with what you want to connect.
I suggest to create new user for this.
 
  

 