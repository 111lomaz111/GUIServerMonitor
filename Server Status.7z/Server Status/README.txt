# GUIServerMonitor

It`s created to show on GUI all parameters of our server(i`ts cpu load, ram etc)

I suggest to create new user for this.
 
  

 